import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../models/pegawai_data.dart';
import '../../models/user_role.dart';
import 'payroll_screen.dart' show formatRupiah;
import '../../theme/app_colors.dart';

/// Ambil semua data THR milik pegawai yang sedang login dari Supabase,
/// diurutkan dari tahun terbaru ke terlama, lalu dipetakan ke model
/// [ThrItem] + [ThrSlipDetail] yang sama persis dipakai UI/PDF di bawah.
Future<List<ThrItem>> _fetchThr(AppUser user) async {
  final userId = Supabase.instance.client.auth.currentUser?.id;
  if (userId == null) return [];

  final rows = await Supabase.instance.client
      .from('thr')
      .select()
      .eq('pegawai_id', userId)
      .order('tahun', ascending: false);

  return (rows as List).map((row) {
    final slip = ThrSlipDetail(
      bulanLabel: 'THR ${row['tahun']}',
      nik: user.nik,
      nama: user.name,
      golongan: user.golonganUntukSlip,
      unitKerja: user.unitKerja,
      jabatan: user.jabatan,
      gapok: (row['gapok'] ?? 0) as int,
      tunjanganIstri: (row['tunjangan_istri'] ?? 0) as int,
      tunjanganAnak: (row['tunjangan_anak'] ?? 0) as int,
      tunjanganJabatan: (row['tunjangan_jabatan'] ?? 0) as int,
      tunjanganPrestasi: (row['tunjangan_prestasi'] ?? 0) as int,
      tunjanganTransportasi: (row['tunjangan_transportasi'] ?? 0) as int,
      tunjanganPangan: (row['tunjangan_pangan'] ?? 0) as int,
      tunjanganBpjsKesehatan: (row['tunjangan_bpjs_kesehatan'] ?? 0) as int,
      tunjanganPerumahan: (row['tunjangan_perumahan'] ?? 0) as int,
      tunjanganBpjsTenagaKerja:
          (row['tunjangan_bpjs_tenaga_kerja'] ?? 0) as int,
      tunjanganPerusahaan: (row['tunjangan_perusahaan'] ?? 0) as int,
      lembur: (row['lembur'] ?? 0) as int,
      tunjanganPajak: (row['tunjangan_pajak'] ?? 0) as int,
      tunjanganAirMinum: (row['tunjangan_air_minum'] ?? 0) as int,
      tunjanganKomunikasi: (row['tunjangan_komunikasi'] ?? 0) as int,
      potonganTrandistPmiLain: (row['potongan_trandist_pmi_lain'] ?? 0) as int,
      potonganDapenma: (row['potongan_dapenma'] ?? 0) as int,
      potonganBpjsTenagaKerja: (row['potongan_bpjs_tenaga_kerja'] ?? 0) as int,
      potonganPerumahan: (row['potongan_perumahan'] ?? 0) as int,
      potonganTunjanganPerusahaan:
          (row['potongan_tunjangan_perusahaan'] ?? 0) as int,
      potonganKorpri: (row['potongan_korpri'] ?? 0) as int,
      potonganPajak: (row['potongan_pajak'] ?? 0) as int,
      potonganBpjsKesehatan: (row['potongan_bpjs_kesehatan'] ?? 0) as int,
      potonganKoperasi: (row['potongan_koperasi'] ?? 0) as int,
      potonganDarmaWanita: (row['potongan_darma_wanita'] ?? 0) as int,
      potonganRekeningAirMinum:
          (row['potongan_rekening_air_minum'] ?? 0) as int,
      potonganKas: (row['potongan_kas'] ?? 0) as int,
      potonganBankBjb: (row['potongan_bank_bjb'] ?? 0) as int,
      potonganBankBjbs: (row['potongan_bank_bjbs'] ?? 0) as int,
      potonganBankBtn: (row['potongan_bank_btn'] ?? 0) as int,
      potonganBankBpr: (row['potongan_bank_bpr'] ?? 0) as int,
      potonganAsuransi: (row['potongan_asuransi'] ?? 0) as int,
      potonganZakatRamadhan: (row['potongan_zakat_ramadhan'] ?? 0) as int,
    );

    return ThrItem(
      tahun: row['tahun'] as String,
      jumlah: slip.jumlahDiterima,
      tanggalCair: (row['tanggal_cair'] ?? '-') as String,
      status: (row['status'] ?? 'Belum Cair') as String,
      gajiPokok: (row['gapok'] ?? 0) as int,
      tunjanganTetap: slip.jumlahPendapatan - ((row['gapok'] ?? 0) as int),
      slip: slip,
    );
  }).toList();
}

/// Halaman THR — didesain ulang mengikuti mockup UI (kartu ringkasan
/// oranye "THR terakhir cair", rincian perhitungan, riwayat per tahun,
/// dan tombol "Cek Detail" yang mengunduh slip THR dalam bentuk PDF).
class ThrScreen extends StatefulWidget {
  final AppUser user;

  const ThrScreen({super.key, required this.user});

  @override
  State<ThrScreen> createState() => _ThrScreenState();
}

class _ThrScreenState extends State<ThrScreen> {
  static const Color navy = Color(0xFF0D2C6E);
  static const Color orangeStart = Color(0xFFF5A623);
  static const Color orangeEnd = Color(0xFFE8890B);
  static const Color totalBg = Color(0xFFDCEBFB);

  bool _isGenerating = false;
  late Future<List<ThrItem>> _thrFuture;

  @override
  void initState() {
    super.initState();
    _thrFuture = _fetchThr(widget.user);
  }

  Future<void> _refresh() async {
    setState(() => _thrFuture = _fetchThr(widget.user));
    await _thrFuture;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).brightness == Brightness.dark ? const Color(0xFF10151C) : const Color(0xFFF3F6F9),
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: FutureBuilder<List<ThrItem>>(
              future: _thrFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return Center(
                    child: Padding(
                      padding: const EdgeInsets.all(40),
                      child: Text(
                        'Gagal memuat data THR: ${snapshot.error}',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppColors.textSecondary(context), fontSize: 13),
                      ),
                    ),
                  );
                }

                final thrList = snapshot.data ?? [];
                final ThrItem? terakhir =
                    thrList.isNotEmpty ? thrList.first : null;
                final riwayat =
                    thrList.length > 1 ? thrList.sublist(1) : <ThrItem>[];

                if (terakhir == null) {
                  return RefreshIndicator(
                    onRefresh: _refresh,
                    child: ListView(
                      children: [
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.all(40),
                            child: Text(
                              'Belum ada data THR',
                              style: TextStyle(color: AppColors.textSecondary(context), fontSize: 13),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }

                return RefreshIndicator(
                  onRefresh: _refresh,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
                    children: [
                      _buildHeroCard(terakhir),
                      const SizedBox(height: 22),
                      _buildSectionLabel('RINCIAN PERHITUNGAN'),
                      const SizedBox(height: 10),
                      _buildRincianCard(terakhir),
                      const SizedBox(height: 22),
                      _buildSectionLabel('RIWAYAT PER TAHUN'),
                      const SizedBox(height: 10),
                      _buildRiwayatCard(riwayat),
                      const SizedBox(height: 24),
                      _buildCekDetailButton(terakhir),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        bottomLeft: Radius.circular(28),
        bottomRight: Radius.circular(28),
      ),
      child: Container(
        width: double.infinity,
        color: navy,
        child: Stack(
          clipBehavior: Clip.hardEdge,
          children: [
            Positioned(
              right: -40,
              top: -30,
              child: Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withOpacity(0.06),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                top: MediaQuery.of(context).padding.top + 14,
                left: 16,
                right: 16,
                bottom: 20,
              ),
              child: Row(
                children: [
                  InkWell(
                    onTap: () => Navigator.pop(context),
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      width: 34,
                      height: 34,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.14),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.chevron_left_rounded,
                          color: Colors.white, size: 22),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    'THR',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeroCard(ThrItem item) {
    final total = item.slip?.jumlahDiterima ?? item.jumlah;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [orangeStart, orangeEnd],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: orangeEnd.withOpacity(0.35),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            'THR terakhir cair',
            style: TextStyle(
              color: Colors.white,
              fontSize: 12.5,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            formatRupiah(total),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            'Dicairkan ${item.tanggalCair}',
            style:
                TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionLabel(String label) {
    return Padding(
      padding: const EdgeInsets.only(left: 4),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: AppColors.textSecondary(context),
          letterSpacing: 0.6,
        ),
      ),
    );
  }

  Widget _buildRincianCard(ThrItem item) {
    final slip = item.slip;

    if (slip == null) {
      return _WhiteCard(
        child: Column(
          children: [
            _plainRow('Gaji pokok', formatRupiah(item.gajiPokok)),
            Divider(height: 1, color: AppColors.divider(context)),
            _plainRow('Tunjangan tetap', formatRupiah(item.tunjanganTetap)),
            const SizedBox(height: 12),
            _highlightRow('Total THR', formatRupiah(item.jumlah)),
          ],
        ),
      );
    }

    final pendapatanLines = slip.pendapatanLines;
    final potonganLines = slip.potonganLines;

    return _WhiteCard(
      child: Column(
        children: [
          for (int i = 0; i < pendapatanLines.length; i++) ...[
            if (i > 0) Divider(height: 1, color: AppColors.divider(context)),
            _plainRow(
              pendapatanLines[i].key,
              formatRupiah(pendapatanLines[i].value),
            ),
          ],
          if (potonganLines.isNotEmpty) ...[
            if (pendapatanLines.isNotEmpty)
              Divider(height: 1, color: AppColors.divider(context)),
            for (int i = 0; i < potonganLines.length; i++) ...[
              if (i > 0) Divider(height: 1, color: AppColors.divider(context)),
              _plainRow(
                potonganLines[i].key,
                formatRupiah(potonganLines[i].value),
              ),
            ],
            const SizedBox(height: 4),
            _plainRow('Jumlah Potongan', formatRupiah(slip.totalPotongan),
                bold: true),
          ],
          const SizedBox(height: 8),
          _highlightRow('Total THR', formatRupiah(slip.jumlahDiterima)),
        ],
      ),
    );
  }

  Widget _highlightRow(String label, String value) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      decoration: BoxDecoration(
        color: totalBg,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 13.5, fontWeight: FontWeight.bold, color: navy)),
          Text(value,
              style: const TextStyle(
                  fontSize: 13.5, fontWeight: FontWeight.bold, color: navy)),
        ],
      ),
    );
  }

  Widget _plainRow(String label, String value, {bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 13),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 13.5,
                color: AppColors.textPrimary(context),
                fontWeight: bold ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 13.5,
              fontWeight: FontWeight.w600,
              color: bold ? navy : AppColors.textPrimary(context),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRiwayatCard(List<ThrItem> riwayat) {
    if (riwayat.isEmpty) {
      return _WhiteCard(
        child: Text(
          'Belum ada riwayat THR tahun sebelumnya',
          style: TextStyle(fontSize: 12.5, color: AppColors.textSecondary(context)),
        ),
      );
    }
    return _WhiteCard(
      child: Column(
        children: [
          for (int i = 0; i < riwayat.length; i++) ...[
            if (i > 0) Divider(height: 1, color: AppColors.divider(context)),
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 13),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('THR ${riwayat[i].tahun}',
                      style: TextStyle(
                          fontSize: 13.5, color: AppColors.textPrimary(context))),
                  Text(
                    formatRupiah(riwayat[i].jumlah),
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSecondary(context),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildCekDetailButton(ThrItem item) {
    return SizedBox(
      width: double.infinity,
      height: 52,
      child: ElevatedButton(
        onPressed: _isGenerating ? null : () => _downloadThrPdf(item),
        style: ElevatedButton.styleFrom(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          elevation: 0,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: _isGenerating
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(
                    strokeWidth: 2.4, color: Colors.white),
              )
            : const Text('Cek Detail',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
      ),
    );
  }

  Future<void> _downloadThrPdf(ThrItem item) async {
    setState(() => _isGenerating = true);
    try {
      final bytes = await _generateThrPdf(item);
      await Printing.sharePdf(bytes: bytes, filename: 'THR_${item.tahun}.pdf');
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal membuat PDF: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isGenerating = false);
    }
  }

  Future<Uint8List> _generateThrPdf(ThrItem item) async {
    final doc = pw.Document();
    const navyColor = PdfColor.fromInt(0xFF0D2C6E);
    const greyColor = PdfColor.fromInt(0xFF8C97A6);

    if (item.slip != null) {
      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(32),
          build: (context) =>
              _buildSlipPdfContent(item, item.slip!, navyColor, greyColor),
        ),
      );
    } else {
      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          margin: const pw.EdgeInsets.all(36),
          build: (context) =>
              _buildSimplePdfContent(item, navyColor, greyColor),
        ),
      );
    }

    return doc.save();
  }

  pw.Widget _buildSlipPdfContent(
    ThrItem item,
    ThrSlipDetail slip,
    PdfColor navyColor,
    PdfColor greyColor,
  ) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Center(
          child: pw.Text(
            slip.perusahaan,
            style: pw.TextStyle(
                fontSize: 12.5,
                fontWeight: pw.FontWeight.bold,
                color: navyColor),
          ),
        ),
        pw.SizedBox(height: 3),
        pw.Center(
          child: pw.Text(
            'DAFTAR THR BULAN : ${slip.bulanLabel}',
            style: pw.TextStyle(fontSize: 10.5, color: greyColor),
          ),
        ),
        pw.SizedBox(height: 12),
        pw.Divider(color: greyColor, thickness: 0.7),
        pw.SizedBox(height: 10),
        _pdfIdentityRow('NIK', widget.user.nik),
        _pdfIdentityRow('NAMA', widget.user.name.toUpperCase()),
        _pdfIdentityRow('GOLONGAN', widget.user.golonganUntukSlip),
        _pdfIdentityRow('UNIT KERJA', widget.user.unitKerja.toUpperCase()),
        _pdfIdentityRow('JABATAN', widget.user.jabatan.toUpperCase()),
        pw.SizedBox(height: 14),
        pw.Divider(color: greyColor, thickness: 0.7),
        pw.SizedBox(height: 10),
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Expanded(
              child: _buildPendapatanColumn(slip, navyColor, greyColor),
            ),
            pw.SizedBox(width: 18),
            pw.Expanded(
              child: _buildPotonganColumn(slip, navyColor, greyColor),
            ),
          ],
        ),
        pw.SizedBox(height: 16),
        pw.Divider(color: greyColor, thickness: 0.7),
        pw.SizedBox(height: 10),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('JUMLAH PENDAPATAN DITERIMA',
                style: pw.TextStyle(
                    fontSize: 11.5,
                    fontWeight: pw.FontWeight.bold,
                    color: navyColor)),
            pw.Text(formatRupiah(slip.jumlahDiterima),
                style: pw.TextStyle(
                    fontSize: 11.5,
                    fontWeight: pw.FontWeight.bold,
                    color: navyColor)),
          ],
        ),
        pw.SizedBox(height: 20),
        pw.Divider(color: greyColor, thickness: 0.7),
        pw.SizedBox(height: 6),
        pw.Text(
          'Slip gaji ini sudah disetujui oleh Direksi. Segala bentuk '
          'penyalahgunaan slip bukan menjadi tanggung jawab perusahaan.',
          style: pw.TextStyle(fontSize: 8, color: greyColor),
        ),
      ],
    );
  }

  pw.Widget _pdfIdentityRow(String label, String value) {
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 3),
      child: pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.SizedBox(
            width: 70,
            child: pw.Text(label, style: const pw.TextStyle(fontSize: 9)),
          ),
          pw.Text(': ', style: const pw.TextStyle(fontSize: 9)),
          pw.Expanded(
            child: pw.Text(value,
                style:
                    pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  pw.Widget _buildPendapatanColumn(
    ThrSlipDetail slip,
    PdfColor navyColor,
    PdfColor greyColor,
  ) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('PENDAPATAN',
            style: pw.TextStyle(
                fontSize: 9.5,
                fontWeight: pw.FontWeight.bold,
                color: greyColor)),
        pw.SizedBox(height: 6),
        _pdfSlipLine('Gaji Pokok', slip.gapok),
        _pdfSlipLine('Tunjangan Istri', slip.tunjanganIstri),
        _pdfSlipLine('Tunjangan Anak', slip.tunjanganAnak),
        _pdfSlipLine('Tunjangan Jabatan', slip.tunjanganJabatan),
        _pdfSlipLine('Tunjangan Prestasi', slip.tunjanganPrestasi),
        _pdfSlipLine('Tunjangan Transportasi', slip.tunjanganTransportasi),
        _pdfSlipLine('Tunjangan Pangan', slip.tunjanganPangan),
        _pdfSlipLine('Tunjangan BPJS Kesehatan', slip.tunjanganBpjsKesehatan),
        _pdfSlipLine('Tunjangan Perumahan', slip.tunjanganPerumahan),
        _pdfSlipLine(
            'Tunjangan BPJS Tenaga Kerja', slip.tunjanganBpjsTenagaKerja),
        _pdfSlipLine('Tunjangan Perusahaan', slip.tunjanganPerusahaan),
        _pdfSlipLine('Lembur', slip.lembur),
        _pdfSlipLine('Tunjangan Pajak', slip.tunjanganPajak),
        _pdfSlipLine('Tunjangan Air Minum', slip.tunjanganAirMinum),
        _pdfSlipLine('Tunjangan Komunikasi', slip.tunjanganKomunikasi),
        pw.SizedBox(height: 4),
        pw.Divider(color: greyColor, thickness: 0.5),
        _pdfSlipLine('Jumlah Pendapatan', slip.jumlahPendapatan,
            bold: true, color: navyColor),
      ],
    );
  }

  pw.Widget _buildPotonganColumn(
    ThrSlipDetail slip,
    PdfColor navyColor,
    PdfColor greyColor,
  ) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('POTONGAN',
            style: pw.TextStyle(
                fontSize: 9.5,
                fontWeight: pw.FontWeight.bold,
                color: greyColor)),
        pw.SizedBox(height: 6),
        _pdfSlipLine(
            'Trandist Potongan PMI / Lain-lain', slip.potonganTrandistPmiLain),
        _pdfSlipLine('Potongan Dapenma', slip.potonganDapenma),
        _pdfSlipLine(
            'Potongan BPJS Tenaga Kerja', slip.potonganBpjsTenagaKerja),
        _pdfSlipLine('Potongan Perumahan', slip.potonganPerumahan),
        _pdfSlipLine(
            'Potongan Tunjangan Perusahaan', slip.potonganTunjanganPerusahaan),
        _pdfSlipLine('Potongan Korpri', slip.potonganKorpri),
        _pdfSlipLine('Potongan Pajak', slip.potonganPajak),
        _pdfSlipLine('Potongan BPJS Kesehatan', slip.potonganBpjsKesehatan),
        pw.SizedBox(height: 4),
        pw.Divider(color: greyColor, thickness: 0.5),
        _pdfSlipLine(
            'Jumlah Potongan Pendapatan', slip.jumlahPotonganPendapatan,
            bold: true, color: navyColor),
        pw.SizedBox(height: 10),
        _pdfSlipLine('Potongan Koperasi', slip.potonganKoperasi),
        _pdfSlipLine('Potongan Darma Wanita', slip.potonganDarmaWanita),
        _pdfSlipLine(
            'Potongan Rekening Air Minum', slip.potonganRekeningAirMinum),
        _pdfSlipLine('Potongan Kas', slip.potonganKas),
        _pdfSlipLine('Potongan Bank BJB', slip.potonganBankBjb),
        _pdfSlipLine('Potongan Bank BJBS', slip.potonganBankBjbs),
        _pdfSlipLine('Potongan Bank BTN', slip.potonganBankBtn),
        _pdfSlipLine('Potongan Bank BPR', slip.potonganBankBpr),
        _pdfSlipLine('Potongan Asuransi', slip.potonganAsuransi),
        _pdfSlipLine('Potongan Zakat Ramadhan', slip.potonganZakatRamadhan),
        pw.SizedBox(height: 4),
        pw.Divider(color: greyColor, thickness: 0.5),
        _pdfSlipLine(
            'Jumlah Potongan Non-Pendapatan', slip.jumlahPotonganNonPendapatan,
            bold: true, color: navyColor),
      ],
    );
  }

  pw.Widget _pdfSlipLine(
    String label,
    int value, {
    bool bold = false,
    PdfColor? color,
  }) {
    final style = pw.TextStyle(
      fontSize: 8.3,
      fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
      color: color,
    );
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 3),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Expanded(child: pw.Text(label, style: style)),
          pw.Text(formatRupiah(value), style: style),
        ],
      ),
    );
  }

  pw.Widget _buildSimplePdfContent(
    ThrItem item,
    PdfColor navyColor,
    PdfColor greyColor,
  ) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(
          'PERUMDAM TIRTA DARMA AYU',
          style: pw.TextStyle(
              fontSize: 11, color: greyColor, fontWeight: pw.FontWeight.bold),
        ),
        pw.SizedBox(height: 4),
        pw.Text(
          'Slip Tunjangan Hari Raya (THR)',
          style: pw.TextStyle(
              fontSize: 20, fontWeight: pw.FontWeight.bold, color: navyColor),
        ),
        pw.SizedBox(height: 2),
        pw.Text('Tahun ${item.tahun}',
            style: pw.TextStyle(fontSize: 12, color: greyColor)),
        pw.SizedBox(height: 20),
        pw.Divider(color: greyColor),
        pw.SizedBox(height: 14),
        _pdfRow('Status', item.status, navyColor),
        pw.SizedBox(height: 8),
        _pdfRow('Tanggal Cair', item.tanggalCair, navyColor),
        pw.SizedBox(height: 20),
        pw.Text(
          'RINCIAN PERHITUNGAN',
          style: pw.TextStyle(
              fontSize: 10, fontWeight: pw.FontWeight.bold, color: greyColor),
        ),
        pw.SizedBox(height: 10),
        _pdfRow('Gaji Pokok', formatRupiah(item.gajiPokok), navyColor),
        pw.SizedBox(height: 8),
        _pdfRow(
            'Tunjangan Tetap', formatRupiah(item.tunjanganTetap), navyColor),
        pw.SizedBox(height: 12),
        pw.Divider(color: greyColor),
        pw.SizedBox(height: 12),
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          children: [
            pw.Text('Total THR',
                style: pw.TextStyle(
                    fontSize: 14,
                    fontWeight: pw.FontWeight.bold,
                    color: navyColor)),
            pw.Text(formatRupiah(item.jumlah),
                style: pw.TextStyle(
                    fontSize: 14,
                    fontWeight: pw.FontWeight.bold,
                    color: navyColor)),
          ],
        ),
        pw.SizedBox(height: 20),
        pw.Divider(color: greyColor),
        pw.SizedBox(height: 6),
        pw.Text(
          'Dokumen ini dibuat otomatis oleh aplikasi SIMPEG Mobile dan sah tanpa tanda tangan basah.',
          style: pw.TextStyle(fontSize: 8.5, color: greyColor),
        ),
      ],
    );
  }

  pw.Widget _pdfRow(String label, String value, PdfColor navyColor) {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Text(label, style: const pw.TextStyle(fontSize: 11)),
        pw.Text(
          value,
          style: pw.TextStyle(
              fontSize: 11, fontWeight: pw.FontWeight.bold, color: navyColor),
        ),
      ],
    );
  }
}

class _WhiteCard extends StatelessWidget {
  final Widget child;

  const _WhiteCard({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: AppColors.card(context),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }
}