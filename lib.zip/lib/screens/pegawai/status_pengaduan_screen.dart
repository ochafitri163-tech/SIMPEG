import 'package:flutter/material.dart';
import '../../models/pengaduan_model.dart';
import '../../models/pengaduan_service.dart';
import '../../models/user_role.dart';
import '../../widgets/feature_scaffold.dart';
import '../shared/detail_pengaduan_screen.dart';


class StatusPengaduanScreen extends StatefulWidget {
  final AppUser user;
  final bool showBackButton;
  const StatusPengaduanScreen({
    super.key,
    required this.user,
    this.showBackButton = true,
  });

  @override
  State<StatusPengaduanScreen> createState() => _StatusPengaduanScreenState();
}

class _StatusPengaduanScreenState extends State<StatusPengaduanScreen> {
  static const Color navy = Color(0xFF0D2C6E);
  static const Color navyDark = Color(0xFF0A2257);
  static const Color accent = Color(0xFF2E86AB);
  static const Color labelDark = Color(0xFF1B2733);
  static const Color hintGrey = Color(0xFF9AA5B1);

  final _searchController = TextEditingController();
  String _query = '';

  Set<PengaduanStatus> _filterStatus = {};
  String? _filterCabang;
  DateTimeRange? _filterTanggal;

  late Future<List<Pengaduan>> _pengaduanFuture;

  @override
  void initState() {
    super.initState();
    _pengaduanFuture = PengaduanService.punyaSayaSebagaiObjek();
  }

  Future<void> _refresh() async {
    setState(() {
      _pengaduanFuture = PengaduanService.punyaSayaSebagaiObjek();
    });
    await _pengaduanFuture;
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<Pengaduan> _filter(List<Pengaduan> semua) {
    return semua.where((p) {
      final q = _query.trim().toLowerCase();
      final matchQuery = q.isEmpty ||
          p.nomorPengaduan.toLowerCase().contains(q) ||
          p.judul.toLowerCase().contains(q) ||
          p.kategori.toLowerCase().contains(q);

      final matchStatus =
          _filterStatus.isEmpty || _filterStatus.contains(p.status);

      final matchCabang = _filterCabang == null || p.cabang == _filterCabang;

      final matchTanggal = _filterTanggal == null ||
          (!p.tanggalPengaduan.isBefore(_filterTanggal!.start) &&
              !p.tanggalPengaduan
                  .isAfter(_filterTanggal!.end.add(const Duration(days: 1))));

      return matchQuery && matchStatus && matchCabang && matchTanggal;
    }).toList()
      ..sort((a, b) => b.tanggalPengaduan.compareTo(a.tanggalPengaduan));
  }

  List<String> _daftarCabang(List<Pengaduan> semua) {
    final set = semua.map((p) => p.cabang).toSet();
    return set.toList()..sort();
  }

  bool get _adaFilterAktif =>
      _filterStatus.isNotEmpty ||
      _filterCabang != null ||
      _filterTanggal != null;

  Future<void> _openFilterSheet(List<Pengaduan> semua) async {
    var tempStatus = {..._filterStatus};
    var tempCabang = _filterCabang;
    var tempTanggal = _filterTanggal;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final isSmallScreen = MediaQuery.of(context).size.width < 400;
            return SafeArea(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.of(context).size.height * 0.88,
                ),
                child: SingleChildScrollView(
                  padding: EdgeInsets.only(
                    left: isSmallScreen ? 16.0 : 20.0,
                    right: isSmallScreen ? 16.0 : 20.0,
                    top: 10,
                    bottom: MediaQuery.of(context).viewInsets.bottom + 20,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 40,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 14),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE0E4E9),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Filter Pengaduan',
                          style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: navy,
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            setSheetState(() {
                              tempStatus = {};
                              tempCabang = null;
                              tempTanggal = null;
                            });
                          },
                          child: const Text('Reset',
                              style: TextStyle(
                                  fontSize: 12.5,
                                  color: hintGrey,
                                  fontWeight: FontWeight.w600)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    const Text('Status',
                        style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.bold,
                            color: labelDark)),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: PengaduanStatus.values.map((s) {
                        final selected = tempStatus.contains(s);
                        return FilterChip(
                          label: Text(s.label,
                              style: TextStyle(
                                fontSize: isSmallScreen ? 10.5 : 11.5,
                                fontWeight: FontWeight.w600,
                                color: selected ? Colors.white : s.color,
                              )),
                          selected: selected,
                          onSelected: (v) {
                            setSheetState(() {
                              if (v) {
                                tempStatus.add(s);
                              } else {
                                tempStatus.remove(s);
                              }
                            });
                          },
                          selectedColor: s.color,
                          backgroundColor: s.color.withValues(alpha: 0.1),
                          checkmarkColor: Colors.white,
                          side: BorderSide(color: s.color.withValues(alpha: 0.3)),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 18),
                    const Text('Cabang',
                        style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.bold,
                            color: labelDark)),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: _daftarCabang(semua).map((c) {
                        final selected = tempCabang == c;
                        return ChoiceChip(
                          label: Text(c,
                              style: TextStyle(
                                fontSize: isSmallScreen ? 10.5 : 11.5,
                                fontWeight: FontWeight.w600,
                                color: selected ? Colors.white : labelDark,
                              )),
                          selected: selected,
                          onSelected: (v) {
                            setSheetState(() {
                              tempCabang = v ? c : null;
                            });
                          },
                          selectedColor: accent,
                          backgroundColor: const Color(0xFFF3F6F9),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 18),
                    const Text('Rentang Tanggal',
                        style: TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.bold,
                            color: labelDark)),
                    const SizedBox(height: 10),
                    InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: () async {
                        final now = DateTime.now();
                        final range = await showDateRangePicker(
                          context: context,
                          firstDate: DateTime(now.year - 2),
                          lastDate: DateTime(now.year + 1),
                          initialDateRange: tempTanggal,
                          builder: (context, child) {
                            return Theme(
                              data: Theme.of(context).copyWith(
                                colorScheme: const ColorScheme.light(
                                  primary: accent,
                                  onPrimary: Colors.white,
                                  onSurface: labelDark,
                                ),
                              ),
                              child: child!,
                            );
                          },
                        );
                        if (range != null) {
                          setSheetState(() => tempTanggal = range);
                        }
                      },
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 14),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF3F6F9),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.date_range_rounded,
                                size: 18, color: accent),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                tempTanggal == null
                                    ? 'Pilih rentang tanggal'
                                    : '${formatTanggalIndonesia(tempTanggal!.start)}  —  ${formatTanggalIndonesia(tempTanggal!.end)}',
                                style: TextStyle(
                                  fontSize: isSmallScreen ? 11.0 : 12.0,
                                  fontWeight: FontWeight.w600,
                                  color: tempTanggal == null
                                      ? hintGrey
                                      : labelDark,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 22),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: ElevatedButton(
                        onPressed: () {
                          setState(() {
                            _filterStatus = tempStatus;
                            _filterCabang = tempCabang;
                            _filterTanggal = tempTanggal;
                          });
                          Navigator.pop(context);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: navy,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                        ),
                        child: const Text('Terapkan Filter',
                            style: TextStyle(
                                fontSize: 14, fontWeight: FontWeight.w600)),
                      ),
                    ),
                  ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 400;

    return Scaffold(
      backgroundColor: const Color(0xFFF3F6F9),
      resizeToAvoidBottomInset: false,
      body: FutureBuilder<List<Pengaduan>>(
        future: _pengaduanFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(
                parent: BouncingScrollPhysics(),
              ),
              slivers: [
                SliverToBoxAdapter(child: _buildHeader(isSmallScreen)),
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(child: CircularProgressIndicator()),
                ),
              ],
            );
          }

          if (snapshot.hasError) {
            return CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(
                parent: BouncingScrollPhysics(),
              ),
              slivers: [
                SliverToBoxAdapter(child: _buildHeader(isSmallScreen)),
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.all(40),
                      child: Text(
                        'Gagal memuat pengaduan: ${snapshot.error}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: hintGrey, fontSize: 13),
                      ),
                    ),
                  ),
                ),
              ],
            );
          }

          final semua = snapshot.data ?? [];
          final items = _filter(semua);

          return RefreshIndicator(
            color: accent,
            onRefresh: _refresh,
            child: CustomScrollView(
              // Header & ringkasan ikut scroll bersama konten (tidak sticky),
              // sesuai permintaan — cukup taruh di dalam CustomScrollView
              // sebagai sliver biasa, bukan lagi Column tetap di luar list.
              physics: const AlwaysScrollableScrollPhysics(
                parent: BouncingScrollPhysics(),
              ),
              slivers: [
                SliverToBoxAdapter(child: _buildHeader(isSmallScreen)),
                SliverToBoxAdapter(
                  child: _buildRingkasanBar(items.length, semua, isSmallScreen),
                ),
                if (items.isEmpty)
                  SliverFillRemaining(
                    hasScrollBody: false,
                    child: EmptyState(
                      message: _adaFilterAktif
                          ? 'Tidak ada pengaduan yang cocok dengan filter ini.'
                          : 'Belum ada pengaduan yang cocok dengan pencarian.',
                      icon: Icons.fact_check_outlined,
                    ),
                  )
                else
                  SliverPadding(
                    padding: EdgeInsets.fromLTRB(
                      isSmallScreen ? 16.0 : 20.0,
                      4,
                      isSmallScreen ? 16.0 : 20.0,
                      24,
                    ),
                    sliver: SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, index) {
                          if (index.isOdd) {
                            return const SizedBox(height: 12);
                          }
                          final itemIndex = index ~/ 2;
                          return _buildPengaduanCard(
                              items[itemIndex], isSmallScreen);
                        },
                        childCount: items.isEmpty ? 0 : items.length * 2 - 1,
                      ),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildRingkasanBar(int jumlah, List<Pengaduan> semua, bool isSmallScreen) {
    return Container(
      width: double.infinity,
      color: const Color(0xFFF3F6F9),
      padding: EdgeInsets.fromLTRB(
        isSmallScreen ? 16.0 : 20.0,
        isSmallScreen ? 14.0 : 18.0,
        isSmallScreen ? 16.0 : 20.0,
        _adaFilterAktif ? (isSmallScreen ? 6.0 : 8.0) : (isSmallScreen ? 10.0 : 14.0),
      ),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(
          horizontal: isSmallScreen ? 14.0 : 16.0,
          vertical: isSmallScreen ? 10.0 : 12.0,
        ),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.04),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: isSmallScreen ? 26.0 : 30.0,
                  height: isSmallScreen ? 26.0 : 30.0,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: accent.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Icon(Icons.fact_check_rounded,
                      size: isSmallScreen ? 14.0 : 16.0, color: accent),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: '$jumlah ',
                          style: TextStyle(
                            fontSize: isSmallScreen ? 13.0 : 14.0,
                            fontWeight: FontWeight.w800,
                            color: labelDark,
                          ),
                        ),
                        TextSpan(
                          text: 'pengaduan ditemukan',
                          style: TextStyle(
                            fontSize: isSmallScreen ? 11.5 : 12.5,
                            fontWeight: FontWeight.w600,
                            color: hintGrey,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                if (_adaFilterAktif)
                  InkWell(
                    borderRadius: BorderRadius.circular(8),
                    onTap: () => setState(() {
                      _filterStatus = {};
                      _filterCabang = null;
                      _filterTanggal = null;
                    }),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 9, vertical: 5),
                      decoration: BoxDecoration(
                        color: accent.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        'Hapus filter',
                        style: TextStyle(
                          fontSize: isSmallScreen ? 10.5 : 11.5,
                          fontWeight: FontWeight.w700,
                          color: accent,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            if (_adaFilterAktif) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final s in _filterStatus)
                  _buildFilterChipAktif(
                    label: s.label,
                    color: s.color,
                    onRemove: () => setState(() => _filterStatus.remove(s)),
                  ),
                if (_filterCabang != null)
                  _buildFilterChipAktif(
                    label: _filterCabang!,
                    color: accent,
                    onRemove: () => setState(() => _filterCabang = null),
                  ),
                if (_filterTanggal != null)
                  _buildFilterChipAktif(
                    label:
                        '${formatTanggalIndonesia(_filterTanggal!.start)} — ${formatTanggalIndonesia(_filterTanggal!.end)}',
                    color: navy,
                    onRemove: () => setState(() => _filterTanggal = null),
                  ),
              ],
            ),
          ],
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChipAktif({
    required String label,
    required Color color,
    required VoidCallback onRemove,
  }) {
    return Container(
      padding: const EdgeInsets.only(left: 10, right: 6, top: 5, bottom: 5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
          const SizedBox(width: 4),
          InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: onRemove,
            child: Icon(Icons.close_rounded, size: 14, color: color),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(bool isSmallScreen) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(
        isSmallScreen ? 16.0 : 20.0,
        MediaQuery.of(context).padding.top + (isSmallScreen ? 8.0 : 12.0),
        isSmallScreen ? 16.0 : 20.0,
        isSmallScreen ? 14.0 : 18.0,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            navy,
            navy.withValues(alpha: 0.85),
            const Color(0xFF123A85)
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(32),
          bottomRight: Radius.circular(32),
        ),
        boxShadow: [
          BoxShadow(
            color: navy.withValues(alpha: 0.25),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withValues(alpha: 0.18)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.water_drop_rounded,
                        size: 11, color: Colors.white70),
                    const SizedBox(width: 5),
                    Text(
                      'PERUMDAM TIRTA DARMA AYU',
                      style: TextStyle(
                        fontSize: isSmallScreen ? 7.0 : 9.0,
                        fontWeight: FontWeight.w700,
                        color: Colors.white.withValues(alpha: 0.75),
                        letterSpacing: 0.6,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              if (widget.showBackButton) ...[
                InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: () => Navigator.maybePop(context),
                  child: Container(
                    width: isSmallScreen ? 28.0 : 36.0,
                    height: isSmallScreen ? 28.0 : 36.0,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.14),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(Icons.chevron_left_rounded,
                        color: Colors.white, size: isSmallScreen ? 18.0 : 22.0),
                  ),
                ),
                const SizedBox(width: 14),
              ],
              Expanded(
                child: Text(
                  'Status Pengaduan',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isSmallScreen ? 15.0 : 17.0,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Padding(
            padding: EdgeInsets.only(left: widget.showBackButton ? (isSmallScreen ? 42.0 : 50.0) : 0.0),
            child: Text(
              'Riwayat seluruh pengaduan yang pernah kamu buat',
              style: TextStyle(
                  color: Colors.white70,
                  fontSize: isSmallScreen ? 10.5 : 11.5),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: Container(
                  height: isSmallScreen ? 38.0 : 44.0,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.08),
                        blurRadius: 10,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.search_rounded,
                          color: hintGrey, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: TextField(
                          controller: _searchController,
                          onChanged: (v) => setState(() => _query = v),
                          style: TextStyle(
                              fontSize: isSmallScreen ? 12.0 : 13.0,
                              color: labelDark),
                          decoration: const InputDecoration(
                            hintText: 'Cari nomor / judul pengaduan',
                            hintStyle:
                                TextStyle(fontSize: 12.5, color: hintGrey),
                            border: InputBorder.none,
                            isCollapsed: true,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 10),
              FutureBuilder<List<Pengaduan>>(
                future: _pengaduanFuture,
                builder: (context, snapshot) {
                  final semua = snapshot.data ?? [];
                  return InkWell(
                    borderRadius: BorderRadius.circular(12),
                    onTap: () => _openFilterSheet(semua),
                    child: Container(
                      width: isSmallScreen ? 38.0 : 44.0,
                      height: isSmallScreen ? 38.0 : 44.0,
                      decoration: BoxDecoration(
                        color: _adaFilterAktif ? accent : Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.08),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Icon(
                        Icons.tune_rounded,
                        color: _adaFilterAktif ? Colors.white : navy,
                        size: isSmallScreen ? 18.0 : 20.0,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  IconData _iconForKategori(String kategori) {
    final k = kategori.toLowerCase();
    if (k.contains('fasilitas')) return Icons.build_circle_rounded;
    if (k.contains('rekan')) return Icons.groups_rounded;
    if (k.contains('atasan')) return Icons.supervisor_account_rounded;
    if (k.contains('gaji') ||
        k.contains('tunjangan') ||
        k.contains('insentif')) {
      return Icons.payments_rounded;
    }
    if (k.contains('kekerasan') || k.contains('pelecehan')) {
      return Icons.shield_rounded;
    }
    if (k.contains('disiplin')) return Icons.gavel_rounded;
    if (k.contains('lingkungan')) return Icons.eco_rounded;
    return Icons.report_gmailerrorred_rounded;
  }

  Widget _buildPengaduanCard(Pengaduan p, bool isSmallScreen) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () {
          final id = p.supabaseId;
          if (id == null) return;
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) =>
                  PengaduanDetailScreen(user: widget.user, pengaduanId: id),
            ),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0xFFEEF1F5)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 14,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Strip status di atas kartu — lebih mudah dipindai mata
              // dibanding badge kecil di pojok.
              Container(
                width: double.infinity,
                padding: EdgeInsets.symmetric(
                  horizontal: isSmallScreen ? 14.0 : 16.0,
                  vertical: isSmallScreen ? 8.0 : 9.0,
                ),
                decoration: BoxDecoration(
                  color: p.status.color.withValues(alpha: 0.1),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(18),
                    topRight: Radius.circular(18),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: p.status.color,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 7),
                    Expanded(
                      child: Text(
                        p.status.label,
                        style: TextStyle(
                          fontSize: isSmallScreen ? 10.5 : 11.5,
                          fontWeight: FontWeight.bold,
                          color: p.status.color,
                          letterSpacing: 0.2,
                        ),
                      ),
                    ),
                    Text(
                      p.nomorPengaduan,
                      style: TextStyle(
                        fontSize: isSmallScreen ? 9.5 : 10.5,
                        fontWeight: FontWeight.w700,
                        color: hintGrey,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(
                  isSmallScreen ? 14.0 : 16.0,
                  isSmallScreen ? 12.0 : 14.0,
                  isSmallScreen ? 14.0 : 16.0,
                  isSmallScreen ? 12.0 : 14.0,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: isSmallScreen ? 40.0 : 46.0,
                          height: isSmallScreen ? 40.0 : 46.0,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: p.status.color.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(13),
                          ),
                          child: Icon(
                            _iconForKategori(p.kategori),
                            size: isSmallScreen ? 19.0 : 21.0,
                            color: p.status.color,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                p.judul,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: isSmallScreen ? 13.5 : 14.5,
                                  fontWeight: FontWeight.bold,
                                  color: labelDark,
                                  height: 1.25,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 9, vertical: 3),
                                decoration: BoxDecoration(
                                  color: accent.withValues(alpha: 0.1),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  p.kategori,
                                  style: TextStyle(
                                    fontSize: isSmallScreen ? 10.0 : 11.0,
                                    fontWeight: FontWeight.w700,
                                    color: accent,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Icon(Icons.calendar_today_rounded,
                            size: isSmallScreen ? 12.0 : 13.0,
                            color: hintGrey),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            formatTanggalIndonesia(p.tanggalPengaduan),
                            style: TextStyle(
                                fontSize: isSmallScreen ? 10.5 : 11.5,
                                fontWeight: FontWeight.w600,
                                color: hintGrey),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: isSmallScreen ? 38.0 : 42.0,
                      child: ElevatedButton(
                        onPressed: () {
                          final id = p.supabaseId;
                          if (id == null) return;
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => PengaduanDetailScreen(
                                  user: widget.user, pengaduanId: id),
                            ),
                          );
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('Lihat Detail',
                                style: TextStyle(
                                    fontSize: isSmallScreen ? 12.0 : 12.5,
                                    fontWeight: FontWeight.w700)),
                            const SizedBox(width: 4),
                            const Icon(Icons.chevron_right_rounded, size: 16),
                          ],
                        ),
                        style: ElevatedButton.styleFrom(
                          foregroundColor: Colors.white,
                          backgroundColor: navy,
                          elevation: 0,
                          padding: EdgeInsets.zero,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(11)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}