import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../login_screen.dart';
import '../../models/pengaduan_model.dart';
import '../../models/pengaduan_service.dart';
import '../../models/user_role.dart';
import '../../widgets/role_guard.dart';
import '../../widgets/notification_bell.dart';
import '../shared/detail_pengaduan_screen.dart';
import '../shared/riwayat_pengaduan_screen.dart';

/// Dashboard untuk role Direktur (DIRUT). Direktur menangani 3 titik dalam
/// alur:
/// 1. Approval Tahap 1 (menungguDirutTahap1) — layak diinvestigasi?
/// 2. Approval Tahap 2 (menungguDirutTahap2) — hasil investigasi diterima?
/// 3. Pilih eksekutor tindak lanjut (menungguPilihEksekutorTindakLanjut)
class DashboardDirutScreen extends StatefulWidget {
  final AppUser user;
  const DashboardDirutScreen({super.key, required this.user});

  @override
  State<DashboardDirutScreen> createState() => _DashboardDirutScreenState();
}

class _DashboardDirutScreenState extends State<DashboardDirutScreen> {
  static const Color _navy = Color(0xFF0D2C6E);
  static const Color _accent = Color(0xFF2E86AB);
  static const Color _green = Color(0xFF27AE60);
  static const Color _red = Color(0xFFE74C3C);

  late Future<List<Pengaduan>> _menungguFuture;
  late Future<List<Pengaduan>> _riwayatFuture;

  @override
  void initState() {
    super.initState();
    _menungguFuture = PengaduanService.untukRoleSebagaiObjek(UserRole.direktur);
    _riwayatFuture = PengaduanService.untukRoleSebagaiObjek(UserRole.direktur);
  }

  Future<void> _refreshMenunggu() async {
    setState(() {
      _menungguFuture =
          PengaduanService.untukRoleSebagaiObjek(UserRole.direktur);
    });
    await _menungguFuture;
  }

  Future<void> _refreshSemua() async {
    setState(() {
      _menungguFuture =
          PengaduanService.untukRoleSebagaiObjek(UserRole.direktur);
      _riwayatFuture =
          PengaduanService.untukRoleSebagaiObjek(UserRole.direktur);
    });
    await Future.wait([_menungguFuture, _riwayatFuture]);
  }

  Future<void> _logout() async {
    await Supabase.instance.client.auth.signOut();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  void _showSnack(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(fontSize: 13)),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  Future<T?> _openSheet<T>(
      Widget Function(BuildContext, void Function(void Function())) builder) {
    return showModalBottomSheet<T>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
          child: Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 24),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: builder(ctx, setSheetState),
          ),
        ),
      ),
    );
  }

  Widget _grip() => Container(
        width: 40,
        height: 4,
        margin: const EdgeInsets.only(bottom: 16),
        decoration: BoxDecoration(
            color: Colors.grey[300], borderRadius: BorderRadius.circular(10)),
      );

  Widget _infoBlok(String label, String value) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
          color: const Color(0xFFF3F6F9),
          borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF7F8C8D))),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 12.5)),
        ],
      ),
    );
  }

  Widget _pilihanTerimaTolak(
    Keputusan current,
    void Function(void Function()) setSheetState,
    void Function(Keputusan) onPick,
  ) {
    return Row(
      children: [
        Expanded(
          child: ChoiceChip(
            label: Text('Terima',
                style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                    color: current == Keputusan.terima ? Colors.white : _navy)),
            selected: current == Keputusan.terima,
            selectedColor: _green,
            onSelected: (_) => setSheetState(() => onPick(Keputusan.terima)),
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: ChoiceChip(
            label: Text('Tolak',
                style: TextStyle(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w600,
                    color: current == Keputusan.tolak ? Colors.white : _navy)),
            selected: current == Keputusan.tolak,
            selectedColor: _red,
            onSelected: (_) => setSheetState(() => onPick(Keputusan.tolak)),
          ),
        ),
      ],
    );
  }

  // ---------- Approval Tahap 1: layak diinvestigasi? ----------
  Future<void> _bukaKeputusanTahap1(Pengaduan p) async {
    Keputusan keputusan = Keputusan.terima;
    final catatanController = TextEditingController();

    final ok = await _openSheet<bool>((ctx, setSheetState) {
      return SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _grip(),
            const Text('Persetujuan Tahap 1',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const Text('Apakah pengaduan ini layak diinvestigasi?',
                style: TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 4),
            Text(p.nomorPengaduan,
                style: const TextStyle(fontSize: 12.5, color: Colors.grey)),
            const SizedBox(height: 14),
            _infoBlok('Judul', p.judul),
            _infoBlok('Deskripsi', p.deskripsi),
            const SizedBox(height: 6),
            _pilihanTerimaTolak(keputusan, setSheetState, (v) => keputusan = v),
            const SizedBox(height: 16),
            TextField(
              controller: catatanController,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: keputusan == Keputusan.tolak
                    ? 'Alasan penolakan (wajib)'
                    : 'Catatan (opsional)',
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  if (keputusan == Keputusan.tolak &&
                      catatanController.text.trim().isEmpty) {
                    _showSnack('Alasan penolakan wajib diisi.', _red);
                    return;
                  }
                  Navigator.pop(ctx, true);
                },
                icon: const Icon(Icons.gavel_rounded, size: 18),
                label: const Text('Simpan Keputusan'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _navy,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
          ],
        ),
      );
    });

    if (ok != true) return;
    final id = p.supabaseId;
    if (id == null) return;

    try {
      await PengaduanService.dirutTahap1Aksi(
        pengaduanId: id,
        oleh: widget.user.name,
        keputusan: keputusan,
        catatan: catatanController.text.trim().isEmpty
            ? null
            : catatanController.text.trim(),
      );

      if (!mounted) return;
      _showSnack(
        keputusan == Keputusan.terima
            ? '${p.nomorPengaduan} disetujui, dikembalikan ke KSPI.'
            : '${p.nomorPengaduan} ditolak & diarsipkan.',
        keputusan == Keputusan.terima ? _green : _red,
      );
      await _refreshSemua();
    } catch (e) {
      if (mounted) _showSnack('Gagal memproses: $e', Colors.red);
    }
  }

  // ---------- Approval Tahap 2: hasil investigasi diterima? ----------
  Future<void> _bukaKeputusanTahap2(Pengaduan p) async {
    Keputusan keputusan = Keputusan.terima;
    final catatanController = TextEditingController();

    final ok = await _openSheet<bool>((ctx, setSheetState) {
      return SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _grip(),
            const Text('Persetujuan Tahap 2',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const Text('Apakah hasil investigasi ini diterima?',
                style: TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 4),
            Text(p.nomorPengaduan,
                style: const TextStyle(fontSize: 12.5, color: Colors.grey)),
            const SizedBox(height: 14),
            _infoBlok('Hasil Investigasi', p.hasilInvestigasi ?? '-'),
            _infoBlok('Surat Rekomendasi', p.suratRekomendasi ?? '-'),
            const SizedBox(height: 6),
            _pilihanTerimaTolak(keputusan, setSheetState, (v) => keputusan = v),
            const SizedBox(height: 16),
            TextField(
              controller: catatanController,
              maxLines: 3,
              decoration: InputDecoration(
                labelText: keputusan == Keputusan.tolak
                    ? 'Alasan penolakan (wajib)'
                    : 'Catatan (opsional)',
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {
                  if (keputusan == Keputusan.tolak &&
                      catatanController.text.trim().isEmpty) {
                    _showSnack('Alasan penolakan wajib diisi.', _red);
                    return;
                  }
                  Navigator.pop(ctx, true);
                },
                icon: const Icon(Icons.gavel_rounded, size: 18),
                label: const Text('Simpan Keputusan'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _navy,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
          ],
        ),
      );
    });

    if (ok != true) return;
    final id = p.supabaseId;
    if (id == null) return;

    try {
      await PengaduanService.direksiTahap2Aksi(
        pengaduanId: id,
        oleh: widget.user.name,
        keputusan: keputusan,
        catatan: catatanController.text.trim().isEmpty
            ? null
            : catatanController.text.trim(),
      );

      if (!mounted) return;
      _showSnack(
        keputusan == Keputusan.terima
            ? '${p.nomorPengaduan} diterima & diteruskan ke SDM.'
            : '${p.nomorPengaduan} ditolak & diarsipkan.',
        keputusan == Keputusan.terima ? _green : _red,
      );

      await _refreshSemua();
    } catch (e) {
      if (mounted) _showSnack('Gagal memproses: $e', Colors.red);
    }
  }

  // ---------- Pilih eksekutor tindak lanjut ----------
  Future<void> _bukaPilihEksekutorTindakLanjut(Pengaduan p) async {
    Eksekutor eksekutorDipilih = Eksekutor.kspi;
    final ok = await _openSheet<bool>((ctx, setSheetState) {
      return SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _grip(),
            const Text('Pilih Eksekutor Tindak Lanjut',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(p.nomorPengaduan,
                style: const TextStyle(fontSize: 12.5, color: Colors.grey)),
            const SizedBox(height: 16),
            Row(
              children: const [Eksekutor.kspi, Eksekutor.tpdpk].map((e) {
                final selected = eksekutorDipilih == e;
                return Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(e.label,
                          style: TextStyle(
                              fontSize: 12,
                              color: selected ? Colors.white : _navy,
                              fontWeight: FontWeight.w600)),
                      selected: selected,
                      selectedColor: _accent,
                      onSelected: (_) =>
                          setSheetState(() => eksekutorDipilih = e),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 18),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.pop(ctx, true),
                icon: const Icon(Icons.flag_rounded, size: 18),
                label: const Text('Tetapkan Eksekutor'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: _navy,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
              ),
            ),
          ],
        ),
      );
    });

    if (ok != true) return;
    final id = p.supabaseId;
    if (id == null) return;

    try {
      await PengaduanService.pilihEksekutorTindakLanjut(
        pengaduanId: id,
        oleh: widget.user.name,
        eksekutor: eksekutorDipilih,
      );

      if (!mounted) return;
      _showSnack(
          'Eksekutor tindak lanjut ditetapkan: ${eksekutorDipilih.label}.',
          _green);
      await _refreshSemua();
    } catch (e) {
      if (mounted) _showSnack('Gagal memproses: $e', Colors.red);
    }
  }

  /// Menentukan aksi utama yang perlu dilakukan Direktur untuk [p], sesuai
  /// status pengaduan saat ini. Return null kalau tidak ada aksi (seharusnya
  /// tidak terjadi karena list sudah difilter, tapi dijaga untuk keamanan).
  void Function()? _aksiUntuk(Pengaduan p) {
    switch (p.status) {
      case PengaduanStatus.menungguDirutTahap1:
        return () => _bukaKeputusanTahap1(p);
      case PengaduanStatus.menungguDirutTahap2:
        return () => _bukaKeputusanTahap2(p);
      case PengaduanStatus.menungguPilihEksekutorTindakLanjut:
        return () => _bukaPilihEksekutorTindakLanjut(p);
      default:
        return null;
    }
  }

  String _labelAksi(Pengaduan p) {
    switch (p.status) {
      case PengaduanStatus.menungguDirutTahap1:
        return 'Putuskan (Tahap 1)';
      case PengaduanStatus.menungguDirutTahap2:
        return 'Putuskan (Tahap 2)';
      case PengaduanStatus.menungguPilihEksekutorTindakLanjut:
        return 'Pilih Eksekutor';
      default:
        return 'Proses';
    }
  }

  @override
  Widget build(BuildContext context) {
    return RoleGuard(
      user: widget.user,
      allowedRoles: const [UserRole.direktur],
      child: Scaffold(
        backgroundColor: const Color(0xFFF3F6F9),
        // Header & kartu profil sekarang ikut discroll dalam satu ListView
        // (tidak lagi sticky), dan kartu profil diletakkan dalam Stack agar
        // selalu tampil di depan header biru (tidak lagi ketimpa/clip).
        body: FutureBuilder<List<Pengaduan>>(
          future: _menungguFuture,
          builder: (context, snapshot) {
            Widget content;

            if (snapshot.connectionState == ConnectionState.waiting) {
              content = const Padding(
                padding: EdgeInsets.only(top: 80),
                child: Center(child: CircularProgressIndicator()),
              );
            } else if (snapshot.hasError) {
              content = Padding(
                padding: const EdgeInsets.all(40),
                child: Text(
                  'Gagal memuat data: ${snapshot.error}',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey[600], fontSize: 13),
                ),
              );
            } else {
              final menunggu = snapshot.data ?? [];

              content = menunggu.isEmpty
                  ? Container(
                      padding: const EdgeInsets.symmetric(vertical: 40),
                      alignment: Alignment.center,
                      child: Column(
                        children: [
                          Icon(Icons.inbox_rounded,
                              size: 48, color: Colors.grey[300]),
                          const SizedBox(height: 10),
                          Text(
                              'Tidak ada pengaduan yang menunggu persetujuan.',
                              style: TextStyle(
                                  fontSize: 12.5, color: Colors.grey[500])),
                        ],
                      ),
                    )
                  : Column(
                      children:
                          menunggu.map((p) => _buildPengaduanCard(p)).toList(),
                    );
            }

            return RefreshIndicator(
              onRefresh: _refreshMenunggu,
              // Struktur disamakan dengan dashboard pegawai: header & kartu
              // ada dalam satu Column yang discroll bersama (topbar ikut
              // ikut ke atas saat discroll, tidak lagi sticky), dan kartu
              // profil "mengambang" lewat Transform.translate — Column
              // tidak meng-clip contentnya seperti ListView, jadi kartu
              // selalu tampil di depan header, jarak/spacing pun sama
              // persis seperti kartu jadwal di dashboard pegawai.
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTopHeader(context),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Transform.translate(
                            offset: const Offset(0, -28),
                            child: _buildProfileCard(
                                snapshot.data?.length ?? 0),
                          ),
                          const SizedBox(height: 18),
                          content,
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildTopHeader(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 400;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.fromLTRB(
        isSmallScreen ? 16.0 : 20.0,
        MediaQuery.of(context).padding.top + (isSmallScreen ? 10.0 : 14.0),
        isSmallScreen ? 12.0 : 16.0,
        isSmallScreen ? 40.0 : 56.0,
      ),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            _navy,
            _navy.withValues(alpha: 0.85),
            const Color(0xFF123A85),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(28),
          bottomRight: Radius.circular(28),
        ),
        boxShadow: [
          BoxShadow(
            color: _navy.withValues(alpha: 0.2),
            blurRadius: 20,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Persetujuan Direktur',
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: isSmallScreen ? 18.0 : 21.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.history_rounded, color: Colors.white),
                tooltip: 'Riwayat Pengaduan',
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => RiwayatPengaduanScreen(user: widget.user),
                  ),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.refresh_rounded, color: Colors.white),
                tooltip: 'Muat ulang',
                onPressed: _refreshSemua,
              ),
              const IconTheme(
                data: IconThemeData(color: Colors.white),
                child: NotificationBell(role: UserRole.direktur),
              ),
              IconButton(
                icon: const Icon(Icons.logout_rounded, color: Colors.white),
                tooltip: 'Keluar',
                onPressed: _logout,
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'Setujui & pantau riwayat keputusan pengaduan',
            style: TextStyle(
              color: Colors.white.withValues(alpha: 0.75),
              fontSize: isSmallScreen ? 11.0 : 12.5,
            ),
          ),
        ],
      ),
    );
  }

  /// Kartu putih profil yang mengambang di atas header, meniru persis
  /// kartu jadwal pada dashboard pegawai (ukuran, radius, bayangan).
  Widget _buildProfileCard(int jumlah) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 400;
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: isSmallScreen ? 14.0 : 18.0,
        vertical: isSmallScreen ? 12.0 : 16.0,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: _accent.withValues(alpha: 0.04),
            blurRadius: 30,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: isSmallScreen ? 42.0 : 46.0,
            height: isSmallScreen ? 42.0 : 46.0,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [_navy, _accent],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              shape: BoxShape.circle,
              image: widget.user.fotoUrl != null
                  ? DecorationImage(
                      image: NetworkImage(widget.user.fotoUrl!),
                      fit: BoxFit.cover,
                    )
                  : null,
            ),
            child: widget.user.fotoUrl != null
                ? null
                : Text(
                    widget.user.initials,
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: isSmallScreen ? 14.0 : 16.0,
                    ),
                  ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.user.name,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: isSmallScreen ? 12.5 : 14.0,
                    fontWeight: FontWeight.w700,
                    color: _navy,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '${widget.user.role.label} · ${widget.user.jabatan}',
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w500,
                    color: Color(0xFF95A5A6),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: _accent.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('$jumlah',
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: _navy)),
                const Text('Menunggu',
                    style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: _accent)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPengaduanCard(Pengaduan p) {
    final aksi = _aksiUntuk(p);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 3))
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(p.nomorPengaduan,
                      style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: _accent)),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                      color: p.status.color.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8)),
                  child: Text(p.status.label,
                      style: TextStyle(
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          color: p.status.color)),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(p.judul,
                style: const TextStyle(
                    fontSize: 13.5, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(
              p.status == PengaduanStatus.menungguDirutTahap2
                  ? 'Rekomendasi: ${p.suratRekomendasi ?? '-'}'
                  : p.deskripsi,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11.5, color: Colors.grey),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      final id = p.supabaseId;
                      if (id == null) return;
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => PengaduanDetailScreen(
                              user: widget.user, pengaduanId: id),
                        ),
                      );
                    },
                    icon: const Icon(Icons.visibility_outlined, size: 16),
                    label: const Text('Detail', style: TextStyle(fontSize: 12)),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _navy,
                      side: const BorderSide(color: _navy),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(9)),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: aksi,
                    icon: const Icon(Icons.gavel_rounded, size: 16),
                    label: Text(_labelAksi(p),
                        style: const TextStyle(fontSize: 12)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _navy,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(9)),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRiwayatCard(Pengaduan p) {
    final riwayatDirektur =
        p.riwayatStatus.where((h) => h.role == UserRole.direktur).toList();
    final terakhirDirektur =
        riwayatDirektur.isNotEmpty ? riwayatDirektur.last : null;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 3))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(p.nomorPengaduan,
                    style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: _accent)),
              ),
              if (terakhirDirektur != null)
                Text(formatTanggalJam(terakhirDirektur.tanggal),
                    style: const TextStyle(fontSize: 11, color: Colors.grey)),
            ],
          ),
          const SizedBox(height: 6),
          Text(p.judul,
              style:
                  const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(terakhirDirektur?.aksi ?? '-',
              style: const TextStyle(fontSize: 12, color: Colors.grey)),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
                color: p.status.color.withOpacity(0.12),
                borderRadius: BorderRadius.circular(8)),
            child: Text(p.status.label,
                style: TextStyle(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    color: p.status.color)),
          ),
        ],
      ),
    );
  }
}